# Android: launch screen without a logo

This repository does **not** ship a full Android app. If you wrap **UserGuide.html** in a WebView or host it inside your own Android app, use the following so the **system splash (Android 12+)** does not show your app icon as a centered “logo”.

## Option A — Solid splash only (no icon)

1. Add a color, e.g. `res/values/colors.xml`:

```xml
<color name="splash_background">#0f1419</color>
```

2. Add a drawable that matches the splash background exactly (so there is no visible “logo”), e.g. `res/drawable/splash_brand.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="@color/splash_background" />
</shape>
```

3. In `res/values/themes.xml`, point the splash theme at your background and use the **same-color** icon (not your app logo):

```xml
<style name="Theme.App.Starting" parent="Theme.SplashScreen">
    <item name="windowSplashScreenBackground">@color/splash_background</item>
    <item name="windowSplashScreenAnimatedIcon">@drawable/splash_brand</item>
    <item name="windowSplashScreenAnimationDuration">0</item>
    <item name="postSplashScreenTheme">@style/Theme.App</item>
</style>
```

4. Apply `Theme.App.Starting` to your launcher `<activity>` in `AndroidManifest.xml`, then in `Activity.onCreate` (before `super.onCreate`) install the splash screen API if you use AndroidX `core-splashscreen`.

**Note:** A fully **transparent** `windowSplashScreenAnimatedIcon` can look odd on some OEMs; matching **icon color to background** usually looks like “no logo”.

## Option B — User guide only in Chrome (no native shell)

Open **UserGuide.html** in Chrome on Android. With `display: "browser"` in `UserGuide.webmanifest` and **no** `icons` entry, there is no installable PWA icon from this repo—avoid “Add to Home screen” if you want to skip any install splash entirely.
